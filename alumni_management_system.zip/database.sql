CREATE DATABASE IF NOT EXISTS alumni_management;
USE alumni_management;

CREATE TABLE IF NOT EXISTS admins (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS alumni (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  batch_year INT NOT NULL,
  department VARCHAR(100) NOT NULL,
  company VARCHAR(120),
  job_role VARCHAR(120),
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS events (
  id INT PRIMARY KEY AUTO_INCREMENT,
  event_name VARCHAR(150) NOT NULL,
  event_date DATE NOT NULL,
  venue VARCHAR(150),
  description VARCHAR(500)
);

CREATE TABLE IF NOT EXISTS event_registrations (
  id INT PRIMARY KEY AUTO_INCREMENT,
  event_id INT NOT NULL,
  alumni_id INT NOT NULL,
  registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status VARCHAR(30) NOT NULL DEFAULT 'Registered',
  UNIQUE KEY uq_event_alumni (event_id, alumni_id),
  CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
  CONSTRAINT fk_reg_alumni FOREIGN KEY (alumni_id) REFERENCES alumni(id) ON DELETE CASCADE
);

-- Demo admin: username admin, password Admin@123
-- Password is stored as a BCrypt hash by the application on first setup.
INSERT IGNORE INTO admins(username, password_hash) VALUES
('admin', '$2a$10$7EqJtq98hPqEX7fNZaFWoO5u6gXQvJ0v9x1sZ6tZ6n3xQ8Jv5m9yK');

INSERT IGNORE INTO alumni(id,name,batch_year,department,company,job_role,email,phone) VALUES
(1,'Ananya Raman',2021,'Computer Science','Zoho','Software Engineer','ananya@example.com','9876543210'),
(2,'Arjun Kumar',2020,'Information Tech','TCS','Systems Analyst','arjun@example.com','9876543211'),
(4,'Karthik Raj',2021,'Computer Science','Zoho','QA Engineer','karthik@example.com','9876543213');

INSERT IGNORE INTO events(id,event_name,event_date,venue,description) VALUES
(1,'Alumni Meet 2026','2026-12-15','Main Auditorium','Annual alumni gathering'),
(2,'Career Guidance','2026-11-20','Seminar Hall','Career guidance and networking session');
