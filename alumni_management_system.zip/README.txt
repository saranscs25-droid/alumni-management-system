================================================================================
ALUMNI MANAGEMENT SYSTEM (Java Swing + MySQL)
================================================================================

PROJECT OVERVIEW
----------------
A complete desktop application built with Java Swing and MySQL database
connectivity for institutional alumni relations, event management, and 
career placement tracking.

KEY FEATURES
------------
1. Executive Dashboard:
   - Live KPI cards: Total Alumni, Active Events, Registrations, Partner Companies.
   - Real-time preview tables for recent enrollments and upcoming events.
2. Alumni Management (CRUD):
   - Add, Update, and Delete Alumni profiles.
   - Comprehensive validation (name, 4-digit batch year, department, email format).
   - Real-time search by Name, Department, or Company.
   - One-click CSV export for offline reporting.
3. Event Management & Registrations:
   - Create, edit, and delete institutional events.
   - Smart Alumni Registration: interactive alumni dropdown list or numeric ID.
   - Unregister attendees with confirmation.
   - Export event attendee lists to CSV.
4. Career & Job Search:
   - Multi-criteria filter by Batch Year, Department, Company, and Job Role.
   - Instant search results with record counters.
   - Export career matching results to CSV.
5. Database & Diagnostics:
   - Self-healing database initializer (creates missing tables automatically).
   - In-app connection tester and credential manager.
   - Live status indicator (Online/Offline) in bottom status bar.

PREREQUISITES
-------------
- Java JDK 17 or higher
- MySQL Server 8.x (running on port 3306)
- MySQL Connector/J 8.x JAR (included in lib/)

DATABASE CONFIGURATION
----------------------
Database credentials are automatically managed via db.properties:
  db.url=jdbc:mysql://localhost:3306/alumni_management?serverTimezone=Asia/Kolkata&useSSL=false&allowPublicKeyRetrieval=true
  db.user=root
  db.password=1234$#@

You can also adjust credentials in the 'Database & Settings' tab inside the application.

DEFAULT ADMINISTRATOR LOGIN
---------------------------
  Username: admin
  Password: Admin@123

HOW TO RUN
----------
Option 1 (Easiest - Windows):
  Double-click `run.bat`

Option 2 (Command Line):
  cd "c:\Users\mgash\Downloads\saravanavel java"
  javac -cp ".;lib\mysql-connector-j-8.3.0.jar;lib\*" AlumniManagementSystem.java
  java -cp ".;lib\mysql-connector-j-8.3.0.jar;lib\*" AlumniManagementSystem
================================================================================
