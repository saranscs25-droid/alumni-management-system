import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.Vector;

/**
 * ============================================================================
 * Alumni Management System
 * ============================================================================
 * A complete Java Swing + MySQL desktop application for managing alumni
 * records, event registrations, and career placement searches.
 *
 * Core Features:
 *  - Secure Administrator Login with Database & Demo Authentication
 *  - Interactive Dashboard with Live Statistical Cards
 *  - Full Alumni CRUD (Create, Read, Update, Delete) with Search & CSV Export
 *  - Event Management with Date Validation & Registrations Tracking
 *  - Visual Alumni Selection for Event Registrations (Dropdown + ID input)
 *  - Multi-Criteria Job & Placement Search Filter
 *  - Database Configuration Manager & Self-Healing Table Initializer
 *
 * Requirements: JDK 17+ and MySQL Connector/J 8.x
 * ============================================================================
 */
public class AlumniManagementSystem {

    // -------------------------------------------------------------------------
    // Visual Palette & Fonts
    // -------------------------------------------------------------------------
    private static final Color COLOR_PRIMARY    = new Color(30, 58, 138);   // Deep Navy Blue
    private static final Color COLOR_ACCENT     = new Color(37, 99, 235);   // Royal Blue
    private static final Color COLOR_SUCCESS    = new Color(22, 163, 74);   // Forest Green
    private static final Color COLOR_DANGER     = new Color(220, 38, 38);   // Crimson Red
    private static final Color COLOR_NEUTRAL    = new Color(100, 116, 139); // Slate Gray
    private static final Color COLOR_BG         = new Color(248, 250, 252); // Off-White
    private static final Color COLOR_CARD       = Color.WHITE;
    private static final Color COLOR_BORDER     = new Color(226, 232, 240);
    private static final Color COLOR_TEXT_DARK  = new Color(15, 23, 42);

    private static final Font FONT_HEADER_TITLE = new Font("Segoe UI", Font.BOLD, 22);
    private static final Font FONT_HEADER_SUB   = new Font("Segoe UI", Font.PLAIN, 12);
    private static final Font FONT_SECTION      = new Font("Segoe UI", Font.BOLD, 15);
    private static final Font FONT_LABEL        = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_BODY         = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BTN          = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_STAT_NUM     = new Font("Segoe UI", Font.BOLD, 26);
    private static final Font FONT_STAT_LABEL   = new Font("Segoe UI", Font.PLAIN, 12);

    // -------------------------------------------------------------------------
    // Database Configuration & State
    // -------------------------------------------------------------------------
    private static final String CONFIG_FILE = "db.properties";
    private String dbUrl;
    private String dbUser;
    private String dbPassword;

    // -------------------------------------------------------------------------
    // UI Components
    // -------------------------------------------------------------------------
    private JFrame mainFrame;
    private JLabel statusLabel;
    private JLabel dbStatusIndicator;
    private String currentAdminUser = "admin";

    // Dashboard UI
    private JLabel statAlumniCount;
    private JLabel statEventsCount;
    private JLabel statRegCount;
    private JLabel statCompaniesCount;
    private DefaultTableModel recentAlumniModel;
    private DefaultTableModel upcomingEventsModel;

    // Alumni Management UI
    private JTextField nameField, batchField, deptField, companyField, roleField, emailField, phoneField;
    private JTextField alumniSearchField;
    private DefaultTableModel alumniModel;
    private JTable alumniTable;

    // Event Management UI
    private JTextField eventNameField, eventDateField, eventVenueField, eventDescField;
    private DefaultTableModel eventsModel;
    private JTable eventsTable;
    private JComboBox<EventChoice> eventChoiceDropdown;
    private DefaultTableModel registrationModel;
    private JTable registrationTable;

    // Job Search UI
    private JTextField jobBatchField, jobDeptField, jobCompanyField, jobRoleField;
    private DefaultTableModel jobModel;
    private JTable jobTable;
    private JLabel jobCountLabel;

    // Settings UI
    private JTextField cfgUrlField, cfgUserField;
    private JPasswordField cfgPassField;

    // -------------------------------------------------------------------------
    // Entry Point
    // -------------------------------------------------------------------------
    public static void main(String[] args) {
        // Set modern look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            AlumniManagementSystem app = new AlumniManagementSystem();
            app.loadConfiguration();
            app.ensureDatabaseInitialized();
            app.showLogin();
        });
    }

    // -------------------------------------------------------------------------
    // Database Configuration & Connection Methods
    // -------------------------------------------------------------------------
    private void loadConfiguration() {
        Properties props = new Properties();
        File f = new File(CONFIG_FILE);

        if (f.exists()) {
            try (FileInputStream in = new FileInputStream(f)) {
                props.load(in);
            } catch (IOException e) {
                System.err.println("Notice: Could not load " + CONFIG_FILE + ": " + e.getMessage());
            }
        }

        // Priority order: db.properties -> Environment Variables -> Smart Defaults
        this.dbUrl = props.getProperty("db.url",
                System.getenv().getOrDefault("AMS_DB_URL",
                        "jdbc:mysql://localhost:3306/alumni_management?serverTimezone=Asia/Kolkata&useSSL=false&allowPublicKeyRetrieval=true"));

        this.dbUser = props.getProperty("db.user",
                System.getenv().getOrDefault("AMS_DB_USER", "root"));

        this.dbPassword = props.getProperty("db.password",
                System.getenv().getOrDefault("AMS_DB_PASSWORD", "1234$#@"));
    }

    private void saveConfiguration(String url, String user, String password) throws IOException {
        Properties props = new Properties();
        props.setProperty("db.url", url);
        props.setProperty("db.user", user);
        props.setProperty("db.password", password);

        try (FileOutputStream out = new FileOutputStream(CONFIG_FILE)) {
            props.store(out, "Alumni Management System Database Configuration");
        }

        this.dbUrl = url;
        this.dbUser = user;
        this.dbPassword = password;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    /**
     * Self-healing: Creates database and tables automatically if they don't exist.
     */
    private void ensureDatabaseInitialized() {
        // First try connecting to the full URL
        try (Connection conn = getConnection()) {
            createTablesIfNotExist(conn);
            return;
        } catch (SQLException ex) {
            // If the database doesn't exist yet, connect to MySQL server root to create it
            try {
                String baseUrl = "jdbc:mysql://localhost:3306/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata";
                try (Connection rootConn = DriverManager.getConnection(baseUrl, dbUser, dbPassword);
                     Statement st = rootConn.createStatement()) {
                    st.executeUpdate("CREATE DATABASE IF NOT EXISTS alumni_management");
                }
                try (Connection conn = getConnection()) {
                    createTablesIfNotExist(conn);
                }
            } catch (Exception e) {
                System.err.println("Notice: Database initialization will be verified on login: " + e.getMessage());
            }
        }
    }

    private void createTablesIfNotExist(Connection c) throws SQLException {
        try (Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS admins (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "password_hash VARCHAR(255) NOT NULL)");

            s.executeUpdate("CREATE TABLE IF NOT EXISTS alumni (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "name VARCHAR(120) NOT NULL, " +
                    "batch_year INT NOT NULL, " +
                    "department VARCHAR(100) NOT NULL, " +
                    "company VARCHAR(120), " +
                    "job_role VARCHAR(120), " +
                    "email VARCHAR(150) NOT NULL UNIQUE, " +
                    "phone VARCHAR(20))");

            s.executeUpdate("CREATE TABLE IF NOT EXISTS events (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "event_name VARCHAR(150) NOT NULL, " +
                    "event_date DATE NOT NULL, " +
                    "venue VARCHAR(150), " +
                    "description VARCHAR(500))");

            s.executeUpdate("CREATE TABLE IF NOT EXISTS event_registrations (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "event_id INT NOT NULL, " +
                    "alumni_id INT NOT NULL, " +
                    "registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "status VARCHAR(30) NOT NULL DEFAULT 'Registered', " +
                    "UNIQUE KEY uq_event_alumni (event_id, alumni_id), " +
                    "CONSTRAINT fk_reg_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE, " +
                    "CONSTRAINT fk_reg_alumni FOREIGN KEY (alumni_id) REFERENCES alumni(id) ON DELETE CASCADE)");
        }
    }

    // -------------------------------------------------------------------------
    // Login Screen
    // -------------------------------------------------------------------------
    private void showLogin() {
        JFrame login = new JFrame("Alumni Management System - Admin Login");
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        login.setSize(520, 420);
        login.setLocationRelativeTo(null);
        login.setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(COLOR_BG);

        // Header
        JPanel banner = new JPanel();
        banner.setLayout(new BoxLayout(banner, BoxLayout.Y_AXIS));
        banner.setBackground(COLOR_PRIMARY);
        banner.setBorder(new EmptyBorder(22, 28, 20, 28));

        JLabel titleLbl = new JLabel("Alumni Management System");
        titleLbl.setFont(FONT_HEADER_TITLE);
        titleLbl.setForeground(Color.WHITE);
        titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subLbl = new JLabel("Administrative Portal & Database Access");
        subLbl.setFont(FONT_HEADER_SUB);
        subLbl.setForeground(new Color(219, 234, 254));
        subLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        banner.add(titleLbl);
        banner.add(Box.createVerticalStrut(4));
        banner.add(subLbl);
        root.add(banner, BorderLayout.NORTH);

        // Form Card
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(COLOR_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(20, 35, 20, 35),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(COLOR_BORDER, 1),
                        BorderFactory.createEmptyBorder(20, 25, 20, 25)
                )
        ));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 6, 8, 6);
        g.fill = GridBagConstraints.HORIZONTAL;

        JLabel loginHeader = new JLabel("Sign In with Administrator Credentials", SwingConstants.CENTER);
        loginHeader.setFont(FONT_SECTION);
        loginHeader.setForeground(COLOR_TEXT_DARK);
        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        card.add(loginHeader, g);

        // Username
        g.gridwidth = 1;
        g.gridy = 1; g.gridx = 0;
        JLabel uLbl = new JLabel("Username:");
        uLbl.setFont(FONT_LABEL);
        card.add(uLbl, g);

        JTextField usernameField = new JTextField("admin", 18);
        usernameField.setFont(FONT_BODY);
        g.gridx = 1;
        card.add(usernameField, g);

        // Password
        g.gridy = 2; g.gridx = 0;
        JLabel pLbl = new JLabel("Password:");
        pLbl.setFont(FONT_LABEL);
        card.add(pLbl, g);

        JPasswordField passwordField = new JPasswordField("Admin@123", 18);
        passwordField.setFont(FONT_BODY);
        g.gridx = 1;
        card.add(passwordField, g);

        // Login Button
        JButton loginBtn = createStyledButton("Sign In", COLOR_ACCENT, Color.WHITE);
        loginBtn.setPreferredSize(new Dimension(140, 36));
        g.gridx = 0; g.gridy = 3; g.gridwidth = 2;
        card.add(loginBtn, g);

        // Demo Hint
        JLabel hint = new JLabel("Demo Access: admin / Admin@123", SwingConstants.CENTER);
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(COLOR_NEUTRAL);
        g.gridy = 4;
        card.add(hint, g);

        root.add(card, BorderLayout.CENTER);

        // Action Listener
        ActionListener loginAction = e -> {
            String u = usernameField.getText().trim();
            String p = new String(passwordField.getPassword()).trim();

            if (authenticate(u, p)) {
                this.currentAdminUser = u;
                login.dispose();
                showDashboard();
            } else {
                JOptionPane.showMessageDialog(login,
                        "Invalid credentials. Please verify username and password.\nDemo login: admin / Admin@123",
                        "Authentication Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        };

        loginBtn.addActionListener(loginAction);
        passwordField.addActionListener(loginAction);
        usernameField.addActionListener(loginAction);

        login.setContentPane(root);
        login.setVisible(true);
    }

    private boolean authenticate(String user, String pass) {
        // Built-in demo admin fallback
        if ("admin".equals(user) && "Admin@123".equals(pass)) {
            return true;
        }

        // Check database admins table
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT password_hash FROM admins WHERE username = ?")) {
            ps.setString(1, user);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hash = rs.getString("password_hash");
                    // Check direct match, SHA-256 match, or BCrypt prefix demo
                    if (pass.equals(hash)) return true;
                    if (sha256(pass).equalsIgnoreCase(hash)) return true;
                    if (hash.startsWith("$2a$") && "Admin@123".equals(pass)) return true;
                }
            }
        } catch (Exception e) {
            System.err.println("Database login check fallback: " + e.getMessage());
        }

        return false;
    }

    private String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    // -------------------------------------------------------------------------
    // Main Application Dashboard
    // -------------------------------------------------------------------------
    private void showDashboard() {
        mainFrame = new JFrame("Alumni Management System - Executive Dashboard");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1280, 800);
        mainFrame.setMinimumSize(new Dimension(1080, 680));
        mainFrame.setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(COLOR_BG);

        // Header Banner with Profile & Logout
        root.add(buildMainHeader(), BorderLayout.NORTH);

        // Navigation Tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.setBackground(COLOR_BG);

        tabs.addTab("  Dashboard Overview  ", buildDashboardPanel());
        tabs.addTab("  Alumni Directory  ", buildAlumniPanel());
        tabs.addTab("  Events & Registrations  ", buildEventsPanel());
        tabs.addTab("  Job & Placement Search  ", buildJobPanel());
        tabs.addTab("  Database & Settings  ", buildSettingsPanel());

        root.add(tabs, BorderLayout.CENTER);

        // Bottom Status Bar
        root.add(buildStatusBar(), BorderLayout.SOUTH);

        mainFrame.setContentPane(root);
        mainFrame.setVisible(true);

        // Initial Data Load
        refreshAllData();
    }

    private JPanel buildMainHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(COLOR_PRIMARY);
        header.setBorder(new EmptyBorder(12, 24, 12, 24));

        // Left Branding
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel title = new JLabel("ALUMNI MANAGEMENT SYSTEM");
        title.setFont(FONT_HEADER_TITLE);
        title.setForeground(Color.WHITE);

        JLabel subtitle = new JLabel("Central Institutional Alumni Relations & Career Network");
        subtitle.setFont(FONT_HEADER_SUB);
        subtitle.setForeground(new Color(219, 234, 254));

        left.add(title);
        left.add(Box.createVerticalStrut(2));
        left.add(subtitle);
        header.add(left, BorderLayout.WEST);

        // Right Info & Actions
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 4));
        right.setOpaque(false);

        JLabel userLbl = new JLabel("Logged in as: " + currentAdminUser + "  |");
        userLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        userLbl.setForeground(new Color(226, 232, 240));
        right.add(userLbl);

        JButton logoutBtn = createStyledButton("Sign Out", new Color(185, 28, 28), Color.WHITE);
        logoutBtn.setPreferredSize(new Dimension(95, 30));
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(mainFrame,
                    "Are you sure you want to sign out?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                mainFrame.dispose();
                showLogin();
            }
        });
        right.add(logoutBtn);

        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.WHITE);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, COLOR_BORDER),
                new EmptyBorder(6, 18, 6, 18)
        ));

        statusLabel = new JLabel("System ready.");
        statusLabel.setFont(FONT_BODY);
        statusLabel.setForeground(COLOR_TEXT_DARK);
        bar.add(statusLabel, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        right.setOpaque(false);

        dbStatusIndicator = new JLabel("[Online] Database: Connected", SwingConstants.RIGHT);
        dbStatusIndicator.setFont(new Font("Segoe UI", Font.BOLD, 12));
        dbStatusIndicator.setForeground(COLOR_SUCCESS);
        right.add(dbStatusIndicator);

        JLabel timeLbl = new JLabel(LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
        timeLbl.setFont(FONT_BODY);
        timeLbl.setForeground(COLOR_NEUTRAL);
        right.add(timeLbl);

        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    private void setStatus(String msg) {
        if (statusLabel != null) {
            statusLabel.setText(msg);
        }
    }

    // -------------------------------------------------------------------------
    // TAB 1: Dashboard Overview
    // -------------------------------------------------------------------------
    private JPanel buildDashboardPanel() {
        JPanel p = createPagePanel();

        // 4 KPI Stat Cards
        JPanel statsGrid = new JPanel(new GridLayout(1, 4, 16, 0));
        statsGrid.setOpaque(false);

        statAlumniCount     = new JLabel("0", SwingConstants.CENTER);
        statEventsCount     = new JLabel("0", SwingConstants.CENTER);
        statRegCount        = new JLabel("0", SwingConstants.CENTER);
        statCompaniesCount  = new JLabel("0", SwingConstants.CENTER);

        statsGrid.add(createStatCard("Total Alumni", statAlumniCount, new Color(37, 99, 235)));
        statsGrid.add(createStatCard("Active Events", statEventsCount, new Color(13, 148, 136)));
        statsGrid.add(createStatCard("Event Registrations", statRegCount, new Color(217, 119, 6)));
        statsGrid.add(createStatCard("Partner Companies", statCompaniesCount, new Color(124, 58, 237)));

        p.add(statsGrid, BorderLayout.NORTH);

        // Dual Preview Tables (Recent Alumni & Upcoming Events)
        JPanel tablesPanel = new JPanel(new GridLayout(1, 2, 16, 0));
        tablesPanel.setOpaque(false);

        // Recent Alumni Card
        JPanel alumniCard = createCardPanel("Recently Enrolled Alumni");
        recentAlumniModel = createReadOnlyModel("ID", "Name", "Batch", "Department", "Company");
        JTable recentTable = createStyledTable(recentAlumniModel);
        alumniCard.add(new JScrollPane(recentTable), BorderLayout.CENTER);
        tablesPanel.add(alumniCard);

        // Upcoming Events Card
        JPanel eventsCard = createCardPanel("Upcoming Events Schedule");
        upcomingEventsModel = createReadOnlyModel("ID", "Event Name", "Date", "Venue");
        JTable upcomingTable = createStyledTable(upcomingEventsModel);
        eventsCard.add(new JScrollPane(upcomingTable), BorderLayout.CENTER);
        tablesPanel.add(eventsCard);

        p.add(tablesPanel, BorderLayout.CENTER);
        return p;
    }

    private JPanel createStatCard(String labelText, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel(new BorderLayout(8, 8));
        card.setBackground(COLOR_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDER, 1),
                new EmptyBorder(16, 18, 16, 18)
        ));

        // Color accent top strip
        JPanel topStrip = new JPanel();
        topStrip.setBackground(accent);
        topStrip.setPreferredSize(new Dimension(0, 4));
        card.add(topStrip, BorderLayout.NORTH);

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);

        valueLabel.setFont(FONT_STAT_NUM);
        valueLabel.setForeground(accent);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lbl = new JLabel(labelText, SwingConstants.CENTER);
        lbl.setFont(FONT_STAT_LABEL);
        lbl.setForeground(COLOR_NEUTRAL);
        lbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        content.add(Box.createVerticalStrut(6));
        content.add(valueLabel);
        content.add(Box.createVerticalStrut(4));
        content.add(lbl);

        card.add(content, BorderLayout.CENTER);
        return card;
    }

    // -------------------------------------------------------------------------
    // TAB 2: Alumni Directory (Full CRUD)
    // -------------------------------------------------------------------------
    private JPanel buildAlumniPanel() {
        JPanel p = createPagePanel();

        // Top: Input Form
        JPanel formCard = createCardPanel("Alumni Details Form");
        nameField    = new JTextField();
        batchField   = new JTextField();
        deptField    = new JTextField();
        companyField = new JTextField();
        roleField    = new JTextField();
        emailField   = new JTextField();
        phoneField   = new JTextField();
        alumniSearchField = new JTextField();

        JPanel fields = new JPanel(new GridLayout(2, 4, 12, 10));
        fields.setOpaque(false);
        fields.add(createFieldWrapper("Full Name *", nameField));
        fields.add(createFieldWrapper("Batch Year *", batchField));
        fields.add(createFieldWrapper("Department *", deptField));
        fields.add(createFieldWrapper("Company", companyField));
        fields.add(createFieldWrapper("Job Role", roleField));
        fields.add(createFieldWrapper("Email Address *", emailField));
        fields.add(createFieldWrapper("Phone Number", phoneField));
        fields.add(createFieldWrapper("Quick Search (Name)", alumniSearchField));

        formCard.add(fields, BorderLayout.CENTER);

        // Buttons
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        actions.setOpaque(false);

        JButton addBtn     = createStyledButton("Add Alumni", COLOR_SUCCESS, Color.WHITE);
        JButton updateBtn  = createStyledButton("Update Selected", COLOR_ACCENT, Color.WHITE);
        JButton deleteBtn  = createStyledButton("Delete Selected", COLOR_DANGER, Color.WHITE);
        JButton clearBtn   = createStyledButton("Clear Form", COLOR_NEUTRAL, Color.WHITE);
        JButton refreshBtn = createStyledButton("Refresh", COLOR_PRIMARY, Color.WHITE);
        JButton searchBtn  = createStyledButton("Search", COLOR_ACCENT, Color.WHITE);
        JButton exportBtn  = createStyledButton("Export CSV", new Color(13, 148, 136), Color.WHITE);

        addBtn.addActionListener(e -> addAlumni());
        updateBtn.addActionListener(e -> updateAlumni());
        deleteBtn.addActionListener(e -> deleteAlumni());
        clearBtn.addActionListener(e -> clearAlumniFields());
        refreshBtn.addActionListener(e -> refreshAlumni());
        searchBtn.addActionListener(e -> searchAlumni());
        exportBtn.addActionListener(e -> exportTableToCSV(alumniTable, "alumni_records.csv"));
        alumniSearchField.addActionListener(e -> searchAlumni());

        actions.add(addBtn);
        actions.add(updateBtn);
        actions.add(deleteBtn);
        actions.add(clearBtn);
        actions.add(searchBtn);
        actions.add(refreshBtn);
        actions.add(exportBtn);

        formCard.add(actions, BorderLayout.SOUTH);
        p.add(formCard, BorderLayout.NORTH);

        // Bottom: Alumni Table
        JPanel tableCard = createCardPanel("Alumni Directory Records");
        alumniModel = createReadOnlyModel("ID", "Name", "Batch", "Department", "Company", "Job Role", "Email", "Phone");
        alumniTable = createStyledTable(alumniModel);

        // Selection Listener: auto populate form
        alumniTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && alumniTable.getSelectedRow() >= 0) {
                int r = alumniTable.convertRowIndexToModel(alumniTable.getSelectedRow());
                nameField.setText(val(alumniModel, r, 1));
                batchField.setText(val(alumniModel, r, 2));
                deptField.setText(val(alumniModel, r, 3));
                companyField.setText(val(alumniModel, r, 4));
                roleField.setText(val(alumniModel, r, 5));
                emailField.setText(val(alumniModel, r, 6));
                phoneField.setText(val(alumniModel, r, 7));
            }
        });

        tableCard.add(new JScrollPane(alumniTable), BorderLayout.CENTER);
        p.add(tableCard, BorderLayout.CENTER);

        return p;
    }

    private void addAlumni() {
        if (!validateAlumniInput()) return;

        String sql = "INSERT INTO alumni (name, batch_year, department, company, job_role, email, phone) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            fillAlumniStatement(s);
            s.executeUpdate();
            refreshAlumni();
            refreshDashboardMetrics();
            clearAlumniFields();
            setStatus("Alumni added successfully.");
            JOptionPane.showMessageDialog(mainFrame, "Alumni record added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void updateAlumni() {
        int id = getSelectedId(alumniTable, alumniModel);
        if (id < 0) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an alumni record from the table to update.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!validateAlumniInput()) return;

        String sql = "UPDATE alumni SET name=?, batch_year=?, department=?, company=?, job_role=?, email=?, phone=? WHERE id=?";
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            fillAlumniStatement(s);
            s.setInt(8, id);
            s.executeUpdate();
            refreshAlumni();
            refreshDashboardMetrics();
            setStatus("Alumni ID " + id + " updated.");
            JOptionPane.showMessageDialog(mainFrame, "Alumni record updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void deleteAlumni() {
        int id = getSelectedId(alumniTable, alumniModel);
        if (id < 0) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an alumni record to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(mainFrame,
                "Are you sure you want to delete this alumni record?\nAll linked event registrations will also be removed.",
                "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement("DELETE FROM alumni WHERE id = ?")) {
            s.setInt(1, id);
            s.executeUpdate();
            refreshAlumni();
            refreshRegistrations();
            refreshDashboardMetrics();
            clearAlumniFields();
            setStatus("Alumni ID " + id + " deleted.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private boolean validateAlumniInput() {
        String name = nameField.getText().trim();
        String batch = batchField.getText().trim();
        String dept = deptField.getText().trim();
        String email = emailField.getText().trim();

        if (name.isEmpty() || batch.isEmpty() || dept.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame,
                    "Name, Batch Year, Department, and Email are mandatory fields.",
                    "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        try {
            int b = Integer.parseInt(batch);
            if (b < 1950 || b > 2100) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(mainFrame, "Batch Year must be a valid 4-digit year (e.g., 2022).", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(mainFrame, "Please enter a valid email address.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

    private void fillAlumniStatement(PreparedStatement s) throws SQLException {
        s.setString(1, nameField.getText().trim());
        s.setInt(2, Integer.parseInt(batchField.getText().trim()));
        s.setString(3, deptField.getText().trim());
        s.setString(4, companyField.getText().trim());
        s.setString(5, roleField.getText().trim());
        s.setString(6, emailField.getText().trim());
        s.setString(7, phoneField.getText().trim());
    }

    private void clearAlumniFields() {
        nameField.setText("");
        batchField.setText("");
        deptField.setText("");
        companyField.setText("");
        roleField.setText("");
        emailField.setText("");
        phoneField.setText("");
        alumniSearchField.setText("");
        alumniTable.clearSelection();
    }

    private void refreshAlumni() {
        if (alumniModel == null) return;
        alumniModel.setRowCount(0);
        String sql = "SELECT id, name, batch_year, department, company, job_role, email, phone FROM alumni ORDER BY id DESC";

        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) {
            while (r.next()) {
                alumniModel.addRow(new Object[]{
                        r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                        r.getString(5), r.getString(6), r.getString(7), r.getString(8)
                });
            }
            setStatus("Loaded " + alumniModel.getRowCount() + " alumni records.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void searchAlumni() {
        String q = alumniSearchField.getText().trim();
        alumniModel.setRowCount(0);

        String sql = "SELECT id, name, batch_year, department, company, job_role, email, phone " +
                     "FROM alumni WHERE name LIKE ? OR company LIKE ? OR department LIKE ? ORDER BY id DESC";
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, "%" + q + "%");
            s.setString(2, "%" + q + "%");
            s.setString(3, "%" + q + "%");
            try (ResultSet r = s.executeQuery()) {
                while (r.next()) {
                    alumniModel.addRow(new Object[]{
                            r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                            r.getString(5), r.getString(6), r.getString(7), r.getString(8)
                    });
                }
            }
            setStatus("Search found " + alumniModel.getRowCount() + " matching alumni.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    // -------------------------------------------------------------------------
    // TAB 3: Events & Registrations
    // -------------------------------------------------------------------------
    private JPanel buildEventsPanel() {
        JPanel p = createPagePanel();

        // Top Form Card
        JPanel formCard = createCardPanel("Event Management");
        eventNameField = new JTextField();
        eventDateField = new JTextField(LocalDate.now().plusMonths(1).toString());
        eventVenueField = new JTextField();
        eventDescField  = new JTextField();

        JPanel fields = new JPanel(new GridLayout(1, 4, 12, 8));
        fields.setOpaque(false);
        fields.add(createFieldWrapper("Event Name *", eventNameField));
        fields.add(createFieldWrapper("Date (YYYY-MM-DD) *", eventDateField));
        fields.add(createFieldWrapper("Venue", eventVenueField));
        fields.add(createFieldWrapper("Description", eventDescField));

        formCard.add(fields, BorderLayout.CENTER);

        // Buttons
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        actions.setOpaque(false);

        JButton addBtn     = createStyledButton("Create Event", COLOR_SUCCESS, Color.WHITE);
        JButton updateBtn  = createStyledButton("Update Event", COLOR_ACCENT, Color.WHITE);
        JButton deleteBtn  = createStyledButton("Delete Event", COLOR_DANGER, Color.WHITE);
        JButton refreshBtn = createStyledButton("Refresh Events", COLOR_PRIMARY, Color.WHITE);

        addBtn.addActionListener(e -> addEvent());
        updateBtn.addActionListener(e -> updateEvent());
        deleteBtn.addActionListener(e -> deleteEvent());
        refreshBtn.addActionListener(e -> {
            refreshEvents();
            refreshEventChoices();
            refreshRegistrations();
        });

        actions.add(addBtn);
        actions.add(updateBtn);
        actions.add(deleteBtn);
        actions.add(refreshBtn);
        formCard.add(actions, BorderLayout.SOUTH);

        p.add(formCard, BorderLayout.NORTH);

        // Center split: Events Table on Left, Registrations on Right
        JPanel split = new JPanel(new GridLayout(1, 2, 14, 0));
        split.setOpaque(false);

        // Left: Events Table
        JPanel eventsCard = createCardPanel("Scheduled Events");
        eventsModel = createReadOnlyModel("ID", "Event Name", "Date", "Venue", "Description");
        eventsTable = createStyledTable(eventsModel);

        eventsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && eventsTable.getSelectedRow() >= 0) {
                int r = eventsTable.convertRowIndexToModel(eventsTable.getSelectedRow());
                eventNameField.setText(val(eventsModel, r, 1));
                eventDateField.setText(val(eventsModel, r, 2));
                eventVenueField.setText(val(eventsModel, r, 3));
                eventDescField.setText(val(eventsModel, r, 4));

                // Sync the registrations dropdown
                int eventId = Integer.parseInt(val(eventsModel, r, 0));
                selectEventInDropdown(eventId);
            }
        });
        eventsCard.add(new JScrollPane(eventsTable), BorderLayout.CENTER);
        split.add(eventsCard);

        // Right: Event Registrations
        JPanel regCard = createCardPanel("Event Registrations");
        JPanel regToolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        regToolbar.setOpaque(false);

        JLabel selectLbl = new JLabel("Event:");
        selectLbl.setFont(FONT_LABEL);
        regToolbar.add(selectLbl);

        eventChoiceDropdown = new JComboBox<>();
        eventChoiceDropdown.setFont(FONT_BODY);
        eventChoiceDropdown.setPreferredSize(new Dimension(200, 28));
        eventChoiceDropdown.addActionListener(e -> refreshRegistrations());
        regToolbar.add(eventChoiceDropdown);

        JButton registerAlumniBtn = createStyledButton("+ Register Alumni", COLOR_SUCCESS, Color.WHITE);
        JButton unregisterBtn     = createStyledButton("Unregister", COLOR_DANGER, Color.WHITE);
        JButton exportRegBtn      = createStyledButton("Export CSV", new Color(13, 148, 136), Color.WHITE);

        registerAlumniBtn.addActionListener(e -> registerAlumniDialog());
        unregisterBtn.addActionListener(e -> unregisterAlumni());
        exportRegBtn.addActionListener(e -> exportTableToCSV(registrationTable, "event_attendees.csv"));

        regToolbar.add(registerAlumniBtn);
        regToolbar.add(unregisterBtn);
        regToolbar.add(exportRegBtn);

        regCard.add(regToolbar, BorderLayout.NORTH);

        registrationModel = createReadOnlyModel("Reg ID", "Alumni ID", "Name", "Batch", "Department", "Email", "Status");
        registrationTable = createStyledTable(registrationModel);
        regCard.add(new JScrollPane(registrationTable), BorderLayout.CENTER);

        split.add(regCard);
        p.add(split, BorderLayout.CENTER);

        return p;
    }

    private void addEvent() {
        String name = eventNameField.getText().trim();
        String dateStr = eventDateField.getText().trim();
        String venue = eventVenueField.getText().trim();
        String desc = eventDescField.getText().trim();

        if (name.isEmpty() || dateStr.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Event Name and Date are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            LocalDate.parse(dateStr);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Date must follow YYYY-MM-DD format (e.g., 2026-12-25).", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "INSERT INTO events (event_name, event_date, venue, description) VALUES (?, ?, ?, ?)";
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, name);
            s.setDate(2, Date.valueOf(dateStr));
            s.setString(3, venue);
            s.setString(4, desc);
            s.executeUpdate();
            refreshEvents();
            refreshEventChoices();
            refreshDashboardMetrics();
            setStatus("Event '" + name + "' created.");
            JOptionPane.showMessageDialog(mainFrame, "Event created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void updateEvent() {
        int id = getSelectedId(eventsTable, eventsModel);
        if (id < 0) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an event from the table to update.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String name = eventNameField.getText().trim();
        String dateStr = eventDateField.getText().trim();
        String venue = eventVenueField.getText().trim();
        String desc = eventDescField.getText().trim();

        if (name.isEmpty() || dateStr.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "Event Name and Date are required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String sql = "UPDATE events SET event_name=?, event_date=?, venue=?, description=? WHERE id=?";
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            s.setString(1, name);
            s.setDate(2, Date.valueOf(dateStr));
            s.setString(3, venue);
            s.setString(4, desc);
            s.setInt(5, id);
            s.executeUpdate();
            refreshEvents();
            refreshEventChoices();
            setStatus("Event updated.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void deleteEvent() {
        int id = getSelectedId(eventsTable, eventsModel);
        if (id < 0) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an event to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(mainFrame,
                "Are you sure you want to delete this event and all its registrations?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement("DELETE FROM events WHERE id = ?")) {
            s.setInt(1, id);
            s.executeUpdate();
            refreshEvents();
            refreshEventChoices();
            refreshRegistrations();
            refreshDashboardMetrics();
            setStatus("Event ID " + id + " deleted.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void refreshEvents() {
        if (eventsModel == null) return;
        eventsModel.setRowCount(0);
        String sql = "SELECT id, event_name, event_date, venue, description FROM events ORDER BY event_date ASC";

        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) {
            while (r.next()) {
                eventsModel.addRow(new Object[]{
                        r.getInt(1), r.getString(2), r.getDate(3), r.getString(4), r.getString(5)
                });
            }
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private static class EventChoice {
        final int id;
        final String name;
        EventChoice(int id, String name) { this.id = id; this.name = name; }
        @Override public String toString() { return name + " (#" + id + ")"; }
    }

    private static class AlumniChoice {
        final int id;
        final String label;
        AlumniChoice(int id, String name, int batch, String dept) {
            this.id = id;
            this.label = String.format("#%d - %s (%s, %d)", id, name, dept, batch);
        }
        @Override public String toString() { return label; }
    }

    private void refreshEventChoices() {
        if (eventChoiceDropdown == null) return;
        eventChoiceDropdown.removeAllItems();

        try (Connection c = getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery("SELECT id, event_name FROM events ORDER BY event_date DESC")) {
            while (r.next()) {
                eventChoiceDropdown.addItem(new EventChoice(r.getInt(1), r.getString(2)));
            }
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void selectEventInDropdown(int eventId) {
        if (eventChoiceDropdown == null) return;
        for (int i = 0; i < eventChoiceDropdown.getItemCount(); i++) {
            EventChoice ec = eventChoiceDropdown.getItemAt(i);
            if (ec.id == eventId) {
                eventChoiceDropdown.setSelectedIndex(i);
                break;
            }
        }
    }

    /**
     * Interactive Alumni Registration Dialog with Dropdown Selection + Manual ID
     */
    private void registerAlumniDialog() {
        EventChoice event = (EventChoice) eventChoiceDropdown.getSelectedItem();
        if (event == null) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an event first.", "Notice", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Fetch alumni list for dropdown
        Vector<AlumniChoice> alumniList = new Vector<>();
        try (Connection c = getConnection();
             Statement s = c.createStatement();
             ResultSet rs = s.executeQuery("SELECT id, name, batch_year, department FROM alumni ORDER BY name ASC")) {
            while (rs.next()) {
                alumniList.add(new AlumniChoice(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4)));
            }
        } catch (Exception ex) {
            handleDatabaseError(ex);
            return;
        }

        if (alumniList.isEmpty()) {
            JOptionPane.showMessageDialog(mainFrame, "No alumni registered in system yet. Please add alumni records first.", "No Alumni", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JComboBox<AlumniChoice> combo = new JComboBox<>(alumniList);
        JTextField manualIdField = new JTextField(8);

        JPanel panel = new JPanel(new GridLayout(0, 1, 6, 8));
        panel.add(new JLabel("Select Alumni for '" + event.name + "':"));
        panel.add(combo);
        panel.add(new JLabel("Or enter numeric Alumni ID manually:"));
        panel.add(manualIdField);

        int res = JOptionPane.showConfirmDialog(mainFrame, panel, "Register Alumni for Event",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (res == JOptionPane.OK_OPTION) {
            int selectedAlumniId;
            String manual = manualIdField.getText().trim();
            if (!manual.isEmpty()) {
                try {
                    selectedAlumniId = Integer.parseInt(manual);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(mainFrame, "Invalid Alumni ID entered.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                AlumniChoice ch = (AlumniChoice) combo.getSelectedItem();
                if (ch == null) return;
                selectedAlumniId = ch.id;
            }

            String sql = "INSERT INTO event_registrations (event_id, alumni_id) VALUES (?, ?)";
            try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
                s.setInt(1, event.id);
                s.setInt(2, selectedAlumniId);
                s.executeUpdate();
                refreshRegistrations();
                refreshDashboardMetrics();
                setStatus("Alumni #" + selectedAlumniId + " registered for " + event.name);
                JOptionPane.showMessageDialog(mainFrame, "Registration completed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLIntegrityConstraintViolationException dup) {
                JOptionPane.showMessageDialog(mainFrame, "This alumni is already registered for this event.", "Duplicate Registration", JOptionPane.WARNING_MESSAGE);
            } catch (Exception ex) {
                handleDatabaseError(ex);
            }
        }
    }

    private void unregisterAlumni() {
        int regId = getSelectedId(registrationTable, registrationModel);
        if (regId < 0) {
            JOptionPane.showMessageDialog(mainFrame, "Please select an attendee registration row to remove.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(mainFrame,
                "Remove this alumni from the event registration list?",
                "Confirm Removal", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement("DELETE FROM event_registrations WHERE id = ?")) {
            s.setInt(1, regId);
            s.executeUpdate();
            refreshRegistrations();
            refreshDashboardMetrics();
            setStatus("Registration #" + regId + " cancelled.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void refreshRegistrations() {
        if (registrationModel == null) return;
        registrationModel.setRowCount(0);

        EventChoice ch = (EventChoice) eventChoiceDropdown.getSelectedItem();
        if (ch == null) return;

        String sql = "SELECT er.id, a.id, a.name, a.batch_year, a.department, a.email, er.status " +
                     "FROM event_registrations er " +
                     "JOIN alumni a ON a.id = er.alumni_id " +
                     "WHERE er.event_id = ? ORDER BY er.id DESC";

        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql)) {
            s.setInt(1, ch.id);
            try (ResultSet r = s.executeQuery()) {
                while (r.next()) {
                    registrationModel.addRow(new Object[]{
                            r.getInt(1), r.getInt(2), r.getString(3), r.getInt(4),
                            r.getString(5), r.getString(6), r.getString(7)
                    });
                }
            }
            setStatus("Loaded " + registrationModel.getRowCount() + " registrations for " + ch.name);
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    // -------------------------------------------------------------------------
    // TAB 4: Job & Placement Search
    // -------------------------------------------------------------------------
    private JPanel buildJobPanel() {
        JPanel p = createPagePanel();

        JPanel searchCard = createCardPanel("Filter Alumni by Career & Placement Criteria");
        jobBatchField   = new JTextField();
        jobDeptField    = new JTextField();
        jobCompanyField = new JTextField();
        jobRoleField    = new JTextField();

        JPanel fields = new JPanel(new GridLayout(1, 4, 12, 8));
        fields.setOpaque(false);
        fields.add(createFieldWrapper("Batch Year", jobBatchField));
        fields.add(createFieldWrapper("Department", jobDeptField));
        fields.add(createFieldWrapper("Company Name", jobCompanyField));
        fields.add(createFieldWrapper("Job Role", jobRoleField));

        searchCard.add(fields, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        actions.setOpaque(false);

        JButton searchBtn = createStyledButton("Apply Filters", COLOR_ACCENT, Color.WHITE);
        JButton resetBtn  = createStyledButton("Reset / Show All", COLOR_NEUTRAL, Color.WHITE);
        JButton exportBtn = createStyledButton("Export to CSV", new Color(13, 148, 136), Color.WHITE);

        jobCountLabel = new JLabel("Showing all alumni");
        jobCountLabel.setFont(FONT_LABEL);
        jobCountLabel.setForeground(COLOR_PRIMARY);

        searchBtn.addActionListener(e -> searchJobs());
        resetBtn.addActionListener(e -> {
            jobBatchField.setText("");
            jobDeptField.setText("");
            jobCompanyField.setText("");
            jobRoleField.setText("");
            refreshJobs();
        });
        exportBtn.addActionListener(e -> exportTableToCSV(jobTable, "job_search_results.csv"));

        actions.add(searchBtn);
        actions.add(resetBtn);
        actions.add(exportBtn);
        actions.add(Box.createHorizontalStrut(20));
        actions.add(jobCountLabel);

        searchCard.add(actions, BorderLayout.SOUTH);
        p.add(searchCard, BorderLayout.NORTH);

        // Results Table
        JPanel tableCard = createCardPanel("Matching Career Profiles");
        jobModel = createReadOnlyModel("ID", "Name", "Batch", "Department", "Company", "Job Role", "Email", "Phone");
        jobTable = createStyledTable(jobModel);
        tableCard.add(new JScrollPane(jobTable), BorderLayout.CENTER);

        p.add(tableCard, BorderLayout.CENTER);
        return p;
    }

    private void searchJobs() {
        StringBuilder sql = new StringBuilder("SELECT id, name, batch_year, department, company, job_role, email, phone FROM alumni WHERE 1=1");

        String batch = jobBatchField.getText().trim();
        String dept  = jobDeptField.getText().trim();
        String comp  = jobCompanyField.getText().trim();
        String role  = jobRoleField.getText().trim();

        if (!batch.isEmpty()) sql.append(" AND batch_year = ?");
        if (!dept.isEmpty())  sql.append(" AND department LIKE ?");
        if (!comp.isEmpty())  sql.append(" AND company LIKE ?");
        if (!role.isEmpty())  sql.append(" AND job_role LIKE ?");
        sql.append(" ORDER BY id DESC");

        jobModel.setRowCount(0);
        try (Connection c = getConnection(); PreparedStatement s = c.prepareStatement(sql.toString())) {
            int idx = 1;
            if (!batch.isEmpty()) s.setInt(idx++, Integer.parseInt(batch));
            if (!dept.isEmpty())  s.setString(idx++, "%" + dept + "%");
            if (!comp.isEmpty())  s.setString(idx++, "%" + comp + "%");
            if (!role.isEmpty())  s.setString(idx++, "%" + role + "%");

            try (ResultSet r = s.executeQuery()) {
                while (r.next()) {
                    jobModel.addRow(new Object[]{
                            r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                            r.getString(5), r.getString(6), r.getString(7), r.getString(8)
                    });
                }
            }
            jobCountLabel.setText("Found " + jobModel.getRowCount() + " matching records");
            setStatus("Career search returned " + jobModel.getRowCount() + " records.");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    private void refreshJobs() {
        if (jobModel == null) return;
        jobModel.setRowCount(0);
        String sql = "SELECT id, name, batch_year, department, company, job_role, email, phone FROM alumni ORDER BY id DESC";

        try (Connection c = getConnection(); Statement s = c.createStatement(); ResultSet r = s.executeQuery(sql)) {
            while (r.next()) {
                jobModel.addRow(new Object[]{
                        r.getInt(1), r.getString(2), r.getInt(3), r.getString(4),
                        r.getString(5), r.getString(6), r.getString(7), r.getString(8)
                });
            }
            jobCountLabel.setText("Showing all " + jobModel.getRowCount() + " records");
        } catch (Exception ex) {
            handleDatabaseError(ex);
        }
    }

    // -------------------------------------------------------------------------
    // TAB 5: Database & Settings
    // -------------------------------------------------------------------------
    private JPanel buildSettingsPanel() {
        JPanel p = createPagePanel();

        JPanel card = createCardPanel("MySQL Database Configuration");
        cfgUrlField  = new JTextField(this.dbUrl);
        cfgUserField = new JTextField(this.dbUser);
        cfgPassField = new JPasswordField(this.dbPassword);

        JPanel form = new JPanel(new GridLayout(3, 2, 12, 12));
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel l1 = new JLabel("JDBC Connection URL:"); l1.setFont(FONT_LABEL);
        JLabel l2 = new JLabel("MySQL Username:"); l2.setFont(FONT_LABEL);
        JLabel l3 = new JLabel("MySQL Password:"); l3.setFont(FONT_LABEL);

        form.add(l1); form.add(cfgUrlField);
        form.add(l2); form.add(cfgUserField);
        form.add(l3); form.add(cfgPassField);

        card.add(form, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 12));
        actions.setOpaque(false);

        JButton testBtn = createStyledButton("Test Connection", COLOR_ACCENT, Color.WHITE);
        JButton saveBtn = createStyledButton("Save & Reconnect", COLOR_SUCCESS, Color.WHITE);
        JButton initBtn = createStyledButton("Re-initialize Tables", COLOR_PRIMARY, Color.WHITE);

        testBtn.addActionListener(e -> {
            String url = cfgUrlField.getText().trim();
            String user = cfgUserField.getText().trim();
            String pass = new String(cfgPassField.getPassword());
            try (Connection testConn = DriverManager.getConnection(url, user, pass)) {
                JOptionPane.showMessageDialog(mainFrame, "Connection successful! Database is online.", "Success", JOptionPane.INFORMATION_MESSAGE);
                if (dbStatusIndicator != null) {
                    dbStatusIndicator.setText("[Online] Database: Connected");
                    dbStatusIndicator.setForeground(COLOR_SUCCESS);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(mainFrame, "Connection failed:\n" + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        saveBtn.addActionListener(e -> {
            String url = cfgUrlField.getText().trim();
            String user = cfgUserField.getText().trim();
            String pass = new String(cfgPassField.getPassword());
            try {
                saveConfiguration(url, user, pass);
                refreshAllData();
                JOptionPane.showMessageDialog(mainFrame, "Settings saved to " + CONFIG_FILE + " and database refreshed.", "Saved", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(mainFrame, "Could not save settings: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        initBtn.addActionListener(e -> {
            try (Connection c = getConnection()) {
                createTablesIfNotExist(c);
                refreshAllData();
                JOptionPane.showMessageDialog(mainFrame, "Database tables verified/created successfully.", "Tables Initialized", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                handleDatabaseError(ex);
            }
        });

        actions.add(testBtn);
        actions.add(saveBtn);
        actions.add(initBtn);

        card.add(actions, BorderLayout.SOUTH);
        p.add(card, BorderLayout.NORTH);

        return p;
    }

    // -------------------------------------------------------------------------
    // Refresh & Metric Calculations
    // -------------------------------------------------------------------------
    private void refreshAllData() {
        refreshAlumni();
        refreshEvents();
        refreshEventChoices();
        refreshRegistrations();
        refreshJobs();
        refreshDashboardMetrics();
    }

    private void refreshDashboardMetrics() {
        try (Connection c = getConnection()) {
            if (dbStatusIndicator != null) {
                dbStatusIndicator.setText("[Online] Database: Connected");
                dbStatusIndicator.setForeground(COLOR_SUCCESS);
            }

            // Alumni Count
            try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM alumni")) {
                if (r.next() && statAlumniCount != null) statAlumniCount.setText(String.valueOf(r.getInt(1)));
            }

            // Events Count
            try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM events")) {
                if (r.next() && statEventsCount != null) statEventsCount.setText(String.valueOf(r.getInt(1)));
            }

            // Registrations Count
            try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(*) FROM event_registrations")) {
                if (r.next() && statRegCount != null) statRegCount.setText(String.valueOf(r.getInt(1)));
            }

            // Unique Companies Count
            try (Statement s = c.createStatement(); ResultSet r = s.executeQuery("SELECT COUNT(DISTINCT company) FROM alumni WHERE company IS NOT NULL AND company != ''")) {
                if (r.next() && statCompaniesCount != null) statCompaniesCount.setText(String.valueOf(r.getInt(1)));
            }

            // Recent Alumni Preview
            if (recentAlumniModel != null) {
                recentAlumniModel.setRowCount(0);
                try (Statement s = c.createStatement();
                     ResultSet r = s.executeQuery("SELECT id, name, batch_year, department, company FROM alumni ORDER BY id DESC LIMIT 5")) {
                    while (r.next()) {
                        recentAlumniModel.addRow(new Object[]{r.getInt(1), r.getString(2), r.getInt(3), r.getString(4), r.getString(5)});
                    }
                }
            }

            // Upcoming Events Preview
            if (upcomingEventsModel != null) {
                upcomingEventsModel.setRowCount(0);
                try (Statement s = c.createStatement();
                     ResultSet r = s.executeQuery("SELECT id, event_name, event_date, venue FROM events ORDER BY event_date ASC LIMIT 5")) {
                    while (r.next()) {
                        upcomingEventsModel.addRow(new Object[]{r.getInt(1), r.getString(2), r.getDate(3), r.getString(4)});
                    }
                }
            }
        } catch (SQLException ex) {
            if (dbStatusIndicator != null) {
                dbStatusIndicator.setText("[Offline] Database: Disconnected");
                dbStatusIndicator.setForeground(COLOR_DANGER);
            }
        }
    }

    // -------------------------------------------------------------------------
    // CSV Export Utility
    // -------------------------------------------------------------------------
    private void exportTableToCSV(JTable table, String defaultFilename) {
        if (table.getRowCount() == 0) {
            JOptionPane.showMessageDialog(mainFrame, "Table has no records to export.", "Empty Table", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File(defaultFilename));
        int ret = chooser.showSaveDialog(mainFrame);
        if (ret != JFileChooser.APPROVE_OPTION) return;

        File target = chooser.getSelectedFile();
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(target), StandardCharsets.UTF_8))) {
            TableModel m = table.getModel();
            int colCount = m.getColumnCount();

            // Headers
            for (int i = 0; i < colCount; i++) {
                pw.print(escapeCSV(m.getColumnName(i)));
                if (i < colCount - 1) pw.print(",");
            }
            pw.println();

            // Rows
            for (int r = 0; r < m.getRowCount(); r++) {
                for (int c = 0; c < colCount; c++) {
                    Object val = m.getValueAt(r, c);
                    pw.print(escapeCSV(val == null ? "" : val.toString()));
                    if (c < colCount - 1) pw.print(",");
                }
                pw.println();
            }

            setStatus("Exported " + m.getRowCount() + " rows to " + target.getName());
            JOptionPane.showMessageDialog(mainFrame, "Data exported successfully to:\n" + target.getAbsolutePath(), "Export Complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(mainFrame, "Error exporting CSV: " + ex.getMessage(), "Export Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String escapeCSV(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    // -------------------------------------------------------------------------
    // UI Helpers & Component Factories
    // -------------------------------------------------------------------------
    private JPanel createPagePanel() {
        JPanel p = new JPanel(new BorderLayout(14, 14));
        p.setBackground(COLOR_BG);
        p.setBorder(new EmptyBorder(16, 20, 16, 20));
        return p;
    }

    private JPanel createCardPanel(String title) {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBackground(COLOR_CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDER, 1),
                new EmptyBorder(12, 14, 12, 14)
        ));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(FONT_SECTION);
        titleLbl.setForeground(COLOR_TEXT_DARK);
        p.add(titleLbl, BorderLayout.NORTH);

        return p;
    }

    private JPanel createFieldWrapper(String labelText, JTextField field) {
        JPanel p = new JPanel(new BorderLayout(2, 4));
        p.setOpaque(false);

        JLabel lbl = new JLabel(labelText);
        lbl.setFont(FONT_LABEL);
        lbl.setForeground(COLOR_TEXT_DARK);

        field.setFont(FONT_BODY);
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 28));

        p.add(lbl, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JButton createStyledButton(String text, Color bg, Color fg) {
        JButton b = new JButton(text);
        b.setFont(FONT_BTN);
        b.setBackground(bg);
        b.setForeground(fg);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(bg.darker(), 1),
                new EmptyBorder(6, 14, 6, 14)
        ));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private DefaultTableModel createReadOnlyModel(String... cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    private JTable createStyledTable(DefaultTableModel m) {
        JTable t = new JTable(m);
        t.setFont(FONT_BODY);
        t.setRowHeight(28);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setAutoCreateRowSorter(true);
        t.setGridColor(COLOR_BORDER);
        t.setShowVerticalLines(false);
        t.setShowHorizontalLines(true);

        JTableHeader th = t.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 12));
        th.setBackground(new Color(241, 245, 249));
        th.setForeground(COLOR_TEXT_DARK);
        th.setPreferredSize(new Dimension(0, 32));

        return t;
    }

    private int getSelectedId(JTable table, DefaultTableModel model) {
        int r = table.getSelectedRow();
        if (r < 0) return -1;
        int modelRow = table.convertRowIndexToModel(r);
        return Integer.parseInt(model.getValueAt(modelRow, 0).toString());
    }

    private String val(DefaultTableModel m, int r, int c) {
        Object o = m.getValueAt(r, c);
        return o == null ? "" : o.toString();
    }

    private void handleDatabaseError(Exception ex) {
        ex.printStackTrace();
        String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
        setStatus("Error: " + msg);
        JOptionPane.showMessageDialog(mainFrame,
                "Database Operation Failed:\n" + msg +
                "\n\nPlease ensure MySQL server is running, the database 'alumni_management' exists,\n" +
                "and credentials in " + CONFIG_FILE + " or the Settings tab are correct.",
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }
}
