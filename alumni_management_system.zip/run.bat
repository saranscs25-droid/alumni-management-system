@echo off
title Alumni Management System
cd /d "%~dp0"

echo ========================================================
echo         ALUMNI MANAGEMENT SYSTEM (JAVA SWING)
echo ========================================================
echo Checking Java runtime...
java -version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Java is not found in your PATH.
    echo Please install JDK 17 or higher.
    pause
    exit /b 1
)

echo Compiling project...
javac -cp ".;lib\mysql-connector-j-8.3.0.jar;lib\*" AlumniManagementSystem.java
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Compilation failed.
    pause
    exit /b 1
)

echo Launching Alumni Management System...
start "" javaw -cp ".;lib\mysql-connector-j-8.3.0.jar;lib\*" AlumniManagementSystem
echo Application started successfully.
exit /b 0
